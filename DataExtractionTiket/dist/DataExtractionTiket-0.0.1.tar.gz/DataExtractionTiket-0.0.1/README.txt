This library extracts data from the Google Destination Insights website for certain cities
and regions in Indonesia (Jakarta, Bali, East Java).